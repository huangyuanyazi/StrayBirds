<template>
	
	<div id='patentContainer'>
		<f7-navbar class="c-no-after">
			<f7-nav-left>
				专利
			</f7-nav-left>
			<f7-nav-center sliding class='virtualSearch'>
				<a href='page/patent/search.html'>
					<f7-icon fa="search"></f7-icon>
					<span>
					输入您想要的内容
				    </span>
				</a>
			</f7-nav-center>
		</f7-navbar>
		<f7-page name="page_patent" id='page_patent' infinite-scroll @infinite="onInfiniteScroll">
			<patent-filter @getParam='getParamData'></patent-filter>
			<patent-card link='/patent/' v-for='patent in patents' :data="patent"></patent-card>
			<!--<div class="page-content  infinite-scroll-bottom " id='p_pageContent'>-->
			
			<!--<div class="infinite-scroll-preloader" id='p_infinite_preloader'>-->
			<!--<div class="preloader"></div>-->
			<!--</div>-->
			
			<!--</div>-->
			<!--<script id="patent_template" type="text/template7">-->
			<!---->
			<!---->
			<!---->
			<!--</script>-->
			<!--<script type='text/template7' id='ejectTemplate_p'>-->
			<!---->
			<!--</script>-->
		</f7-page>
	</div>
</template>
<script>
    import PatentFilter from "../../conponents/patentFilter.vue"
    import PatentCard from "../../conponents/patentList.vue"
    export default{
        data(){
            return {
                patents: "",
                counter: 0,
                param: {}
            }

        },
        created() {
            $$.getJSON(config.mock.url + '/patent', (data, status, xhr) => {
                this.patents = data;
                console.log('created')
            })
//            this.$on('getParamData', (param) => { //Hub接收事件
//                console.log(param)
//
//            });
        },
        watch: {

            param: {
                handler(curVal, oldVal){
                    console.log('监测param的变化-------')
                    $$.getJSON(config.mock.url + '/patent', this.param, (data, status, xhr) => {
                        this.patents = data;
                    })
                },
                deep: true
            }
        },
        ready(){
            console.log('ready')
        },
        attached() {
            console.log('attached')
        },
        components: {
            patentFilter: PatentFilter,
            patentCard: PatentCard,
        },
        methods: {
            getParamData(data){
                this.param = data;
                console.log('来自组件的数据-------')
                console.log(this.param)
            },
            updatePatentList(){
                $$.getJSON(config.mock.url + '/patent' + this.param, (data, status, xhr) => {
                    this.patents = data;
                    console.log('created')
                })
            }
        }

    }
</script>