/**
 * Created by Administrator on 2017/5/27.
 */
import Vue from "vue/dist/vue.js"
import Vuex from 'vuex'
const state = {}
const mutations = {}
const actions = {}
const getters = {}
export default new Vuex.Store({
    actions,
    state,
    mutations,
    getters
})