## 淘权网前端项目开发规范

#### 目录结构说明

* api 接口服务
* build 前端代码构建
* config 项目配置
* mobile 移动端代码
* mock 模拟接口服务
* site 电脑端代码