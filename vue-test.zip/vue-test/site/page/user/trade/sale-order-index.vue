<template>
    <div class="sale-order-index">
        <h3>销售订单</h3>

    </div>
</template>

<script>
    export default {

    }
</script>