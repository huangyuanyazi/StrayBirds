<template>
    <div class="purchase-order-index">
        <h3>采购订单</h3>

    </div>
</template>

<script>
    export default {

    }
</script>

<style>

</style>