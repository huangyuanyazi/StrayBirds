<template>
    <div class="c-item-edit">
        <h3>商品编辑</h3>
        <p>{{ $route }}</p>
    </div>
</template>

<script>
    export default {
        data () {
            return "好不好"
        }
    }
</script>