/**
 * 网站首页
 */
console.log("本站由淘权网技术部开发^_^\n\n想来淘权工作？请发送简历到：hr@taoquanw.com（并注明来自console）")
import "asset/style/index.less"

console.log("nihao1111")
