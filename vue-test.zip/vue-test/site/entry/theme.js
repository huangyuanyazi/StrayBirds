/**
 * 该文件仅为了让webpack构建公共样式，无需在其他js中手动引用
 */
import "asset/style/theme.less"