/**
 * Created by qiangxl on 2017/3/20.
 */
//创建并写入文件
function createAndWriteFile() {
  //持久化数据保存
  window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {

    console.log('打开的文件系统: ' + fs.name);
    fs.root.getFile($$('#fileTitle').val(), {create: true, exclusive: false},
      function (fileEntry) {

        console.log("是否是个文件？" + fileEntry.isFile.toString());
        // fileEntry.name == 'hangge.txt'
        // fileEntry.fullPath == '/hangge.txt'
        //文件内容
        var dataObj = new Blob([$$('#contentText').val()], {type: 'text/plain'});
        //写入文件
        writeFile(fileEntry, dataObj, false);
        readFile(fileEntry)
      }, onErrorCreateFile);

  }, onErrorLoadFs);
}
function createAndWriteFile_append() {
  //持久化数据保存
  window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {

    console.log('打开的文件系统: ' + fs.name);
    fs.root.getFile($$('#fileTitle').val(), {create: true, exclusive: false},
      function (fileEntry) {

        console.log("是否是个文件？" + fileEntry.isFile.toString());
        // fileEntry.name == 'hangge.txt'
        // fileEntry.fullPath == '/hangge.txt'
        //文件内容
        var dataObj = new Blob([$$('#appendText').val()], {type: 'text/plain'});
        //写入文件
        writeFile(fileEntry, dataObj, true);
        readFile(fileEntry)
      }, onErrorCreateFile);

  }, onErrorLoadFs);
}

function createAndWriteFileTemp() {
  //持久化数据保存
  window.requestFileSystem(LocalFileSystem.TEMPORARY, 5 * 1024 * 1024, function (fs) {

    console.log('打开的文件系统: ' + fs.name);
    fs.root.getFile($$('fileTitle').val(), {create: true, exclusive: false},
      function (fileEntry) {

        console.log("是否是个文件？" + fileEntry.isFile.toString());
        // fileEntry.name == 'hangge.txt'
        // fileEntry.fullPath == '/hangge.txt'
        //文件内容
        var dataObj = new Blob([$$('#contentText').val()], {type: 'text/plain'});
        //写入文件
        writeFile(fileEntry, dataObj, false);
        readFile(fileEntry)
      }, onErrorCreateFile);

  }, onErrorLoadFs);
}

function writeFile(fileEntry, dataObj, isAppend) {
  //创建一个写入对象
  fileEntry.createWriter(function (fileWriter) {

    //文件写入成功
    fileWriter.onwriteend = function () {
      console.log("Successful file read...");
    };

    //文件写入失败
    fileWriter.onerror = function (e) {
      console.log("Failed file read: " + e.toString());
    };

    //如果是最加内容，则定位到文件尾部
    if (isAppend) {
      try {
        fileWriter.seek(fileWriter.length);
      }
      catch (e) {
        console.log("file doesn't exist!");
      }
    }
    fileWriter.write(dataObj);
  });
}


//文件创建失败回调
function onErrorCreateFile(error) {
  console.log("文件创建失败！" + error)
}

//FileSystem加载失败回调
function onErrorLoadFs(error) {
  console.log("文件系统加载失败！" + error)
}
//读取文件
function readFile(fileEntry) {
  fileEntry.file(function (file) {
    var reader = new FileReader();
    reader.onloadend = function () {
      alert(this.result);
    };
    reader.readAsText(file);
  }, onErrorReadFile);
}

//读取文件失败响应
function onErrorReadFile() {
  console.log("文件读取失败!");
}


//创建并写入文件
function createAndWriteFileDir() {
  //临时数据保存
  window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {

    console.log('打开的文件系统: ' + fs.name);
    fs.root.getDirectory($$('#fileDir_first').val(), {create: true}, function (dirEntry) {
      dirEntry.getDirectory($$('#fileDir_second').val(), {create: true}, function (subDirEntry) {
        //createFile(subDirEntry, "hangge.txt");
      }, onErrorGetDir);
    }, onErrorGetDir);

  }, onErrorLoadFsDir);
}

//文件夹创建失败回调
function onErrorGetDir(error) {
  console.log("文件夹创建失败！" + error)
}

//FileSystem加载失败回调
function onErrorLoadFsDir(error) {
  console.log("文件系统加载失败！" + error)
}


function downloadImage() {

  window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {

    console.log('打开的文件系统: ' + fs.name);
    getSampleFile(fs.root);
    fs.root.getFile("taoquanw.png", {create: true, exclusive: false},
      function (fileEntry) {
        readBinaryFile(fileEntry);
      }, onErrorCreateFile);
  }, onErrorLoadFs);
}

//获取图片
function getSampleFile(dirEntry) {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', 'https://static.taoquanw.com/upload/shop/common/05336683708587573.png', true);
  xhr.responseType = 'blob';

  xhr.onload = function () {
    if (this.status == 200) {
      var blob = new Blob([this.response], {type: 'image/png'});
      saveFile(dirEntry, blob, "taoquanw.png");
    }
  };
  xhr.send();
}

//保存图片文件
function saveFile(dirEntry, fileData, fileName) {
  dirEntry.getFile(fileName, {create: true, exclusive: false}, function (fileEntry) {
    writeFilePic(fileEntry, fileData);
  }, onErrorCreateFile);
}

//将图片数据写入到文件中
function writeFilePic(fileEntry, dataObj, isAppend) {
  //创建一个写入对象
  fileEntry.createWriter(function (fileWriter) {
    //文件写入成功
    fileWriter.onwriteend = function () {
      console.log("Successful file write...");
      if (dataObj.type == "image/png") {
        // readBinaryFile(fileEntry);
      }
      else {
        readFile(fileEntry);
      }
    };

    //文件写入失败
    fileWriter.onerror = function (e) {
      console.log("Failed file write: " + e.toString());
    };

    //写入文件
    fileWriter.write(dataObj);
  });
}

function readBinaryFile(fileEntry) {
  fileEntry.file(function (file) {
    var reader = new FileReader();

    reader.onloadend = function () {
      //加载成功显示图片
      var blob = new Blob([new Uint8Array(this.result)], {type: "image/png"});
      displayImage(blob);
    };

    reader.readAsArrayBuffer(file);

  }, onErrorReadFile);
}
//显示图片
function displayImage(blob) {
  var elem = document.getElementById('showDownPic');
  elem.src = window.URL.createObjectURL(blob);
}


myApp.onPageInit('page_file', function () {
  console.debug('page_file初始化')
  $$('#createFile').on('click', function () {
    createAndWriteFile()
  })
  $$('#createFileTemp').on('click', function () {
    createAndWriteFileTemp()
  })
  $$('#fileAppend').on('click', function () {
    createAndWriteFile_append()
  });
  $$('#createFileDir').on('click', function () {
    createAndWriteFileDir()
  })
  $$('#downloadPic').on('click', function () {
    downloadImage()
  })
  $$('#fileId').change(function () {
    var $file = $(this);
    var fileObj = $file[0];
    console.log(fileObj.files[0]);
    var dataURL = window.URL.createObjectURL(fileObj.files[0]);
    console.log(dataURL)
    $$("#filePic").attr('src',dataURL);
    console.debug(fileObj.files[0].toURL())
  })
})