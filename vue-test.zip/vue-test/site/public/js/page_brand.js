/**
 * Created by qiangxl on 2017/3/17.
 */
myApp.onPageInit('page_brand',function () {
$$("#update").on('click',function () {
  alert(11111)
  chcp.fetchUpdate(function(error, data) {
    if(!error) {
      myApp.modal({
        title: "提示",
        text: "有更新，确定更新吗?",
        buttons: [{
          text: '不更新'
        }, {
          text: "立即更新",
          onClick: function() {
            myApp.showPreloader('正在升级，升级完毕应用将自动重启...');
            chcp.installUpdate(function(error) {
              myApp.alert("更新完成", ["提示"]);
            })
          }
        }]
      })
    } else {
      myApp.alert("你当前是最新版本", ["提示"]);
    }
  })
})

});
