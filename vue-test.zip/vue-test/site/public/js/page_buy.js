myApp.onPageInit('page_buy',function () {
$$('#sendGet').on('click',function () {
    $.ajax({

        url: "http://192.168.1.3:9090/User",


        type: "get",


        success:function (data) {
            alert(data)
        },

        error:function(er){


        }

    });
})
})