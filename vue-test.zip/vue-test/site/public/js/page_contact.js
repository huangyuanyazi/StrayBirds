/**
 * Created by qiangxl on 2017/3/20.
 */
myApp.onPageInit('page_contact', function () {
  $$('#contact_test').on('click', function () {
    // create a new contact object
    var contact = navigator.contacts.create();
    contact.displayName = $$('#displayName').val();
    contact.nickname = $$('#nickname').val();            // specify both to support all devices
// populate some fields
    var name = new ContactName();
    name.givenName = $$('#givenName').val();
    name.familyName = $$('#familyName').val();
    contact.name = name;
// save to device
    contact.save(onSuccess_contact, onError);
  })
  console.debug('page_contact初始化')
});
function onSuccess_contact(contact) {
  console.debug("Save"+contact+" Success");
};

function onError(contactError) {
  console.debug("Error = " + contactError.code);
};