/**
 * Created by qiangxl on 2017/3/20.
 */

function audioCapture() {
  //开始录音（最长录制时间：15秒）
  navigator.device.capture.captureAudio(function (mediaFiles) {
    var i, path, len;
    //遍历获取录制的文件（iOS只支持一次录制一个视频或音频）
    for (i = 0, len = mediaFiles.length; i < len; i += 1) {
      console.log(mediaFiles);
      path = mediaFiles[i].fullPath;
      alert("录制成功！\n\n"
        + "文件名：" + mediaFiles[i].name + "\n"
        + "大小：" + mediaFiles[i].size + "\n\n"
        + "localURL地址：" + mediaFiles[i].localURL + "\n\n"
        + "fullPath地址：" + path);
    }
  }, function (error) {
    alert('录制失败！错误码：' + error.code);
  }, {duration: 15});
}
function videoCapture() {
  //开始录像（最长录制时间：15秒）
  navigator.device.capture.captureVideo(function (mediaFiles) {
    var i, path, len;
    //遍历获取录制的文件（iOS只支持一次录制一个视频或音频）
    for (i = 0, len = mediaFiles.length; i < len; i += 1) {
      console.log(mediaFiles);
      path = mediaFiles[i].fullPath;
      alert("录制成功！\n\n"
        + "文件名：" + mediaFiles[i].name + "\n"
        + "大小：" + mediaFiles[i].size + "\n\n"
        + "localURL地址：" + mediaFiles[i].localURL + "\n\n"
        + "fullPath地址：" + path);
    }
  }, function (error) {
    alert('录制失败！错误码：' + error.code);
  }, {duration: 15});
}
  //录制成功


  //录制失败

myApp.onPageInit('page_media_capture', function () {
  $$('#audioCapture').on('click', function () {
    audioCapture()
  });
  $$('#videoCapture').on('click',function () {
    videoCapture()
  })
  console.debug('page_media_capture初始化')
});