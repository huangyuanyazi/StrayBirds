
var dataIndex = 0


//-------------------------------初始化-------------------------------------------------
// $(document).ready(function(){
//   if ($$('#patentView').hasClass('active')) {
//       alert('这是首页');
//     }
// })

var myApp = new Framework7({
  swipeBackPage: true,
  swipePanel: 'left',
  //pushstate，这个参数设置为 true。可以使浏览器的回退键用来，回退分页
  pushstate: true,
  // showBarsOnPageScrollEnd: true,
  precompileTemplates: true,
  template7Pages: true,

  // hideToolbarOnPageScroll:true
});

var mainView = myApp.addView('#patentView', {
  dynamicNavbar: true
});
var userView = myApp.addView('#userView');
var buyView = myApp.addView('#buyView');
var brandView = myApp.addView('#brandView');
var views = myApp.addView('.views');
var $$ = Dom7;


initPageContent_ran();
infiniteScroll();
myApp.onPageInit('page_patent',function (page) {
  initPageContent_ran();
  infiniteScroll();
  // myApp.alert('page_patent初始化')
});

//------------------------tool-tabber中判断加载到哪一个页面的方法----------------
//  var getCurrentView = function () {
//    if ($$('#patentView').hasClass('active')) {
//      alert('这是首页');
//      return mainView;
//    }
//    if ($$('#userView').hasClass('active')) {
//      alert('这是个人中心');
//      return userView;
//    }
//    if ($$('#buyView').hasClass('active')) {
//      alert('这是购物车');
//      return buyView;
//    }
//  }
//  getCurrentView();
//getCurrentView().router.loadPage('about.html');


//------------------------------模拟后台数据函数---------------------------------

function mockData(count, callback) {
  var cards = []
  for (var i = 1; i <= count; i++) {
    dataIndex ++
    cards.push({
      card_header: "一种过滤精细可减震式的混凝土搅拌机" + dataIndex,
      card_price: 1600 + dataIndex,
      card_describ: "实用新型 授权未缴费 截止2017-04-19 " + dataIndex,
      card_type: "机械,搅拌机," + dataIndex,
      card_company:"公司" + dataIndex
    })
  }
  callback({data: cards})
}

//------------------------------根据模板初始化页面---------------------------------
function initPageContent_ran() {
  mockData(5, function (result) {
    console.log(result)
    var context_index = {card: result.data}
    var html_init_index = Template7.templates.template_initPage_index(context_index)
    $$('#content .list-block ul').html(html_init_index)
  })
  //----------------------------------网络获取数据时-------------------------------
  // $$.get("url", function (result, status, xhr) {
  //   var context_index = {card: result}
  //   var html_init_index = Template7.templates.template_initPage_index(context_index)
  //   $$('#content .list-block ul').html(html_init_index)
  // })

}
//------------------------------根据模板无限滚动---------------------
function infiniteScroll() {
// 加载flag
  var loading = false;

// 上次加载的序号
  var lastIndex = $$('.list-block ul li').length;

// 最多可加载的条目
  var maxItems = 1000;

// 每次加载添加多少条目
  var itemsPerLoad = 10;
// 注册'infinite'事件处理函数
  $$('.infinite-scroll').on('infinite', function () {
    // 如果正在加载，则退出
    if (loading) return;

    // 设置flag
    loading = true;

    // 模拟1s的加载过程
    setTimeout(function () {
      // 重置加载flag
      loading = false;

      if (lastIndex >= maxItems) {
        // 加载完毕，则注销无限加载事件，以防不必要的加载
        myApp.detachInfiniteScroll($$('.infinite-scroll'));
        // 删除加载提示符
        $$('.infinite-scroll-preloader').remove();
        return;
      }

      var html_pre_index = '';
      mockData(itemsPerLoad,function (result) {
        var context_index_perLoad = {card: result.data}
        var html_init_index_perLoad = Template7.templates.template_initPage_index(context_index_perLoad);
        html_pre_index=html_init_index_perLoad;
      });
      // //一次加载十个
      // for (var i = lastIndex + 1; i <= lastIndex + itemsPerLoad; i++) {
      //   var context_index_single = {
      //     card_header: card_headers[Math.floor(Math.random() * 4)],
      //     card_price: card_prices[Math.floor(Math.random() * 4)],
      //     card_describ: card_describs[Math.floor(Math.random() * 4)],
      //     card_type: card_types[Math.floor(Math.random() * 4)],
      //     card_company:card_companys[Math.floor(Math.random() * 4)]
      //   }
      //   html_pre_index += Template7.templates.template_index_single(context_index_single);
      // }

      $$('#content .list-block ul').append(html_pre_index);

      // Update last loaded index
      lastIndex = $$('#content ul li').length;
    }, 1000);
  });

}
//---------------------------------筛选栏的点击事件---------------------------------------------------

function sx_fm_res() {

  $$('#zllx').text("发明");
  $$('.grade-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_syxx_res() {
  $$('#zllx').text("实用新型");
  $$('.grade-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_wgsj() {
  $$('#zllx').text("外观设计");
  $$('.grade-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_sqwjf_res() {
  $$('#zlzt').text("授权未缴费");
  $$('.Sort-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_yxz_res() {
  $$('#zlzt').text("已下证");
  $$('.Sort-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_1000_res() {
  $$('#jgfw').text("1000以下");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()

}
function sx_1000_2000_res() {
  $$('#jgfw').text("1000以下");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()

}
function sx_2000_3000_res() {
  $$('#jgfw').text("2000-3000");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_3000_5000_res() {
  $$('#jgfw').text("3000-5000");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_5000_10000_res() {
  $$('#jgfw').text("5000-10000");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_10000_50000_res() {
  $$('#jgfw').text("10000-50000");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_50000_res() {
  $$('#jgfw').text("50000以上");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_mr_res() {
  $$('#pxfs').text("默认");
  $$('.meishi22').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_fbsj_res() {
  $$('#pxfs').text("发布时间");
  $$('.meishi22').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_rq_res() {
  $$('#pxfs').text("人气");
  $$('.meishi22').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_jq_res() {
  $$('#pxfs').text("价格");
  $$('.meishi22').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:44px');
  initPageContent_ran();
  infiniteScroll()
}

//-------------------------------------------------------------









// $$(document).on('click','#content .list-block ul li ', function () {
//   mainView.router.loadPage('pages/demo_zl_detail.html')
//   // myApp.hideToolbar('#toolbar_home');
// })
$$(document).on('click','#content .list-block ul li',function () {
  mainView.router.loadPage('pages/demo_zl_detail.html')
  hideToolbar()
})
/*
$$(document).on('pageInit', function (e) {
  if (e.detail.page.name === 'page_search') {
  }
  if(e.detail.page.name==='home'){
  }
})
*/
function hideToolbar() {
  $$('#toolbar_home').hide()
}

function showToolbar() {
  $$('#toolbar_home').show()
}

console.log('mainView.activePage:'+mainView.activePage.name);



