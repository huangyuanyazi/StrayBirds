//meishi开始
$(document).ready(function () {
  $(document).on('click', '.meishi', function () {

    if ($('.meishi22').hasClass('grade-w-roll')) {
      $('.meishi22').removeClass('grade-w-roll');
      $(this).removeClass('current');
      if (mainView.activePage.name === 'page_seller_detail') {
        $('.screening').attr('style', 'position:static;margin-top:88px');
        $('.subnavbar').attr('style', 'display:-webkit-box')
      } else {
        $('.screening').attr('style', 'position:static;margin-top:44px');
      }
    } else {
      $('.meishi22').addClass('grade-w-roll');
      $(this).addClass('current');
      $(".Regional").removeClass('current');
      $(".Brand").removeClass('current');
      $(".Sort").removeClass('current');
      $('.screening').attr('style', 'position:fixed;top:44px;z-index:9999');
      if (mainView.activePage.name === 'page_seller_detail') {
        $('.subnavbar').attr('style', 'display:none')
      }
      
    }
  });

});

$(document).ready(function () {
  $(document).on('click', '.meishia-w>li', function () {
    $(".meishia-t").css("left", "50%")
  });
});

$(document).ready(function () {
  $(document).on('click', '.meishia-t>li', function () {
    $(".meishia-s").css("left", "50%")
  });
});


//Regional开始----------------------------------------
$(document).ready(function () {
  $(document).on('click', '.Regional', function () {
    if ($('.grade-eject').hasClass('grade-w-roll')) {
      $('.grade-eject').removeClass('grade-w-roll');
      $(this).removeClass('current');
      if (mainView.activePage.name === 'page_seller_detail') {
        $('.screening').attr('style', 'position:static;margin-top:88px');
        $('.subnavbar').attr('style', 'display:-webkit-box')
      } else {
        $('.screening').attr('style', 'position:static;margin-top:44px');
      }
    } else {
      $('.grade-eject').addClass('grade-w-roll');
      $(this).addClass('current');
      $(".meishi").removeClass('current');
      $(".Brand").removeClass('current');
      $(".Sort").removeClass('current');
      $('.screening').attr('style', 'position:fixed;top:44px;z-index:9999');
      if (mainView.activePage.name === 'page_seller_detail') {
        $('.subnavbar').attr('style', 'display:none')
      }
    }
  });
});

$(document).ready(function () {
  $(document).on('click', '#nav_sx_sb', function () {
    $("#gradet1").css("left", "50%");
    $("#gradet2").css("left", "100%");
  })
  $(document).on('click', '#nav_sx_zl', function () {
    $("#gradet2").css("left", "50%");
    $("#gradet1").css("left", "100%");
  })
});

$(document).ready(function () {
  $(document).on('click', '.grade-t>li', function () {
    $(".grade-s").css("left", "50%")
  });
});

//Brand开始

$(document).ready(function () {
  $(document).on('click', '.Brand', function () {
    if ($('.Category-eject').hasClass('grade-w-roll')) {
      $('.Category-eject').removeClass('grade-w-roll');
      $(this).removeClass('current');
      if (mainView.activePage.name === 'page_seller_detail') {
        $('.screening').attr('style', 'position:static;margin-top:88px');
        $('.subnavbar').attr('style', 'display:-webkit-box')
      } else {
        $('.screening').attr('style', 'position:static;margin-top:44px');
      }
    } else {
      $('.Category-eject').addClass('grade-w-roll');
      $(this).addClass('current');
      $(".meishi").removeClass('current');
      $(".Regional").removeClass('current');
      $(".Sort").removeClass('current');
      $('.screening').attr('style', 'position:fixed;top:44px;z-index:9999');
      if (mainView.activePage.name === 'page_seller_detail') {
        $('.subnavbar').attr('style', 'display:none')
      }
    }

  });
});


//Sort开始

$(document).ready(function () {
  $(document).on('click', '.Sort', function () {
    if ($('.Sort-eject').hasClass('grade-w-roll')) {
      $('.Sort-eject').removeClass('grade-w-roll');
      $(this).removeClass('current');
      if (mainView.activePage.name === 'page_seller_detail') {
        $('.screening').attr('style', 'position:static;margin-top:88px');
        $('.subnavbar').attr('style', 'display:-webkit-box')
      } else {
        $('.screening').attr('style', 'position:static;margin-top:44px');
      }
    } else {
      $('.Sort-eject').addClass('grade-w-roll');
      $(this).addClass('current');
      $(".meishi").removeClass('current');
      $(".Regional").removeClass('current');
      $(".Brand").removeClass('current');
      $('.screening').attr('style', 'position:fixed;top:44px;z-index:9999');
      if (mainView.activePage.name === 'page_seller_detail') {
        $('.subnavbar').attr('style', 'display:none')
      }
    }
  });
});


//判断页面是否有弹出
$(document).ready(function () {
  $(document).on('click', '.meishi', function () {
    if ($('.Category-eject').hasClass('grade-w-roll')) {
      $('.Category-eject').removeClass('grade-w-roll');
    }
  });
});
$(document).ready(function () {
  $(document).on('click', '.meishi', function () {
    if ($('.Sort-eject').hasClass('grade-w-roll')) {
      $('.Sort-eject').removeClass('grade-w-roll');
    }
    ;
  });
});
$(document).ready(function () {
  $(document).on('click', '.meishi', function () {
    if ($('.grade-eject').hasClass('grade-w-roll')) {
      $('.grade-eject').removeClass('grade-w-roll');
    }
    ;
  });
});


$(document).ready(function () {
  $(document).on('click', '.Regional', function () {
    if ($('.Category-eject').hasClass('grade-w-roll')) {
      $('.Category-eject').removeClass('grade-w-roll');
    }
  });
});
$(document).ready(function () {
  $(document).on('click', '.Regional', function () {
    if ($('.Sort-eject').hasClass('grade-w-roll')) {
      $('.Sort-eject').removeClass('grade-w-roll');
    }
  });
});
$(document).ready(function () {
  $(document).on('click', '.Regional', function () {
    if ($('.meishi22').hasClass('grade-w-roll')) {
      $('.meishi22').removeClass('grade-w-roll');
    }
    ;

  });
});


$(document).ready(function () {
  $(document).on('click', '.Brand', function () {
    if ($('.Sort-eject').hasClass('grade-w-roll')) {
      $('.Sort-eject').removeClass('grade-w-roll');
    }
    ;
  });
});
$(document).ready(function () {
  $(document).on('click', '.Brand', function () {
    if ($('.grade-eject').hasClass('grade-w-roll')) {
      $('.grade-eject').removeClass('grade-w-roll');
    }
    ;
  });
});
$(document).ready(function () {
  $(document).on('click', '.Brand', function () {
    if ($('.meishi22').hasClass('grade-w-roll')) {
      $('.meishi22').removeClass('grade-w-roll');
    }
  });
});


$(document).ready(function () {
  $(document).on('click', '.Sort', function () {
    if ($('.Category-eject').hasClass('grade-w-roll')) {
      $('.Category-eject').removeClass('grade-w-roll');
    }
  });
});
$(document).ready(function () {
  $(document).on('click', '.Sort', function () {
    if ($('.grade-eject').hasClass('grade-w-roll')) {
      $('.grade-eject').removeClass('grade-w-roll');
    }

  });
});
$(document).ready(function () {
  $(document).on('click', '.Sort', function () {
    if ($('.meishi22').hasClass('grade-w-roll')) {
      $('.meishi22').removeClass('grade-w-roll');
    }

  });
});




