function popup_actionsheet_fx() {
  var buttons = [
    {
      text: '微信',
      bold: true, color: "orange"
    },
    {
      text: '新浪',
      bold: true, color: "green"
    },
    {
      text: 'QQ',
      bold: true, color: "purple"
    },
    {
      text: '取消',
      bold: true, color: "red"
    },
  ];
  myApp.actions(buttons);
}
myApp.onPageInit('zl_detail',function () {
  // myApp.alert('demo_zl_detail初始化')
  hideToolbar();
})
