/**
 * Created by qiangxl on 2017/3/20.
 */
var my_media;
var my_record;
myApp.onPageInit('page_media', function () {
  $$('#openMedia').on('click', function () {
    var path1='cdvfile://localhost/persistent/chengdu.mp3';
    var path2='/android_asset/www/media/tdby.mp3';
    my_media = new Media(path1, function(success){
      alert("Media Init Success"+success);
    }, function (error) {
      alert(error)
    },function (status) {
      alert(status)
    });

// Record audio
    my_media.play();

    var mediaTimer = setInterval(function () {
      // get media amplitude
      my_media.getCurrentAmplitude(
        // success callback
        function (amp) {
          $$('#amp').text(amp + "%");
        },
        // error callback
        function (e) {
          console.log("Error getting amp=" + e);
        }
      );
    }, 1000);

    my_media.getCurrentPosition(
      // success callback
      function (position) {
        if (position > -1) {
          $$('#position').text((position) + " sec");
        }
      },
      // error callback
      function (e) {
        console.log("Error getting pos=" + e);
      }
    );


  });
  $$('#stopMedia').on('click',function () {
    my_media.stop();
    my_media.release();

  })
  $$('#startRecord').on('click',function () {
     my_record = new Media(
      "cdvfile://localhost/recording.mp3",
      function() {
        alert("Success");
      },
      function(e) {
        alert("Error" + e);
      }
    );
    my_record.startRecord();

  })
  $$('#stopRecord').on('click',function () {
    my_record.stopRecord();
  })
  console.debug('page_media初始化')
});