/**
 * Created by qiangxl on 2017/3/20.
 */

myApp.onPageInit('page_baidu_location',function () {
  $$('#openLocation_baidu').on('click',function () {
    baidumap_location.getCurrentPosition(function (result) {
      console.log(JSON.stringify(result, null, 4));
    }, function (error) {

    });
  });
  console.debug('page_baidu_location初始化')
});