/**
 * Created by qiangxl on 2017/3/20.
 */
var watchID_orientation;
function onSuccess_orientation(heading) {
  myApp.alert('Heading: ' + heading.magneticHeading);
};
function onError_orientation(error) {
  myApp.alert('CompassError: ' + error.code);
};
function onSuccess_watch_orientation(heading) {
   myApp.alert( 'Heading: ' + heading.magneticHeading)
};

function onError_watch_orientation(compassError) {
  myApp.alert('Compass error: ' + compassError.code);
};

var options_watch_orientation = {
  frequency: 5000
}; // Update every 3 seconds // Update every 3 seconds
myApp.onPageInit('page_device_orientation',function () {
  console.debug('page_device_orientation初始化')
  $$('#getCurrentHeading').on('click',function () {
    navigator.compass.getCurrentHeading(onSuccess_orientation, onError_orientation);

  });
  $$('#watchHeading').on('click',function () {
    watchID_orientation = navigator.compass.watchHeading(onSuccess_watch_orientation, onError_watch_orientation, options_watch_orientation);
  })
  $$('#clearWatch_orientation').on('click',function () {
    navigator.compass.clearWatch(watchID_orientation);
    myApp.alert('关闭观察模式')

  })
});
