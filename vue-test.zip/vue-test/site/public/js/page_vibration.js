/**
 * Created by qiangxl on 2017/3/20.
 */
myApp.onPageInit('page_vibration', function () {
  $$('#vibration').on('click', function () {
    navigator.vibrate(3000);
  });
  console.debug('page_vibration初始化')
});