/**
 * Created by qiangxl on 2017/3/20.
 */
myApp.onPageInit('page_device',function () {
  $$('#getDeviceInfo').on('click',function () {
    $$("#model").text('model'+device.model);
    $$("#platform").text('platform'+device.platform);
    $$("#uuid").text('uuid'+device.uuid);
    $$("#version").text('version'+device.version);
    $$("#isVirtual").text('isVirtual'+device.isVirtual);
    $$("#serial").text('serial'+device.serial);
  })
})