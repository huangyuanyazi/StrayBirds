/**
 * Created by qiangxl on 2017/3/20.
 */
function alertDismissed(){
  myApp.alert('原生alert消失了')
}
function onConfirm(buttonIndex) {
  alert('You selected button ' + buttonIndex);
}
function onPrompt(results) {
  alert("You selected button number " + results.buttonIndex + " and entered " + results.input1);
}
myApp.onPageInit('page_dialog',function () {
  console.debug('page_dialog初始化')
  $$('#getAlert').on('click',function () {
    navigator.notification.alert(
      'You are the winner!',  // message
      alertDismissed,         // callback
      'Game Over',            // title
      'Done'                  // buttonName
    );

  });
  $$('#getConfirm').on('click',function () {
    navigator.notification.confirm(
      'You are the winner!', // message
      onConfirm,            // callback to invoke with index of button pressed
      'Game Over',           // title
      ['Restart','Exit']     // buttonLabels
    );
  })
  $$('#getPrompt').on('click',function () {
    navigator.notification.prompt(
      'Please enter your name',  // message
      onPrompt,                  // callback to invoke
      'Registration',            // title
      ['Ok','Exit'],             // buttonLabels
      'Jane Doe'                 // defaultText
    );
  })
  $$('#getBeep').on('click',function () {
    // Beep twice!
    navigator.notification.beep(2);
  })
});
