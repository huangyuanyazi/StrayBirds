/**
 * Created by qiangxl on 2017/3/20.
 */
myApp.onPageInit('page_inappbrowser', function () {
  $$('#openPageInAppBrowser').on('click', function () {
    var ref = cordova.InAppBrowser.open('https://www.taoquanw.com/', '_blank', 'location=yes');
      ref.addEventListener('loadstart', function (event) {
        alert(event.url);
      });
  });
  console.debug('page_inappbrowser初始化')
});