/**
 * Created by qiangxl on 2017/3/20.
 */
function alertDismissed(){
  myApp.alert('原生alert消失了')
}
function onConfirm(buttonIndex) {
  alert('You selected button ' + buttonIndex);
}
function onPrompt(results) {
  alert("You selected button number " + results.buttonIndex + " and entered " + results.input1);
}
myApp.onPageInit('page_globalization',function () {
  console.debug('page_globalization初始化')
  $$('#getCurrencyPattern').on('click',function () {
    navigator.globalization.getCurrencyPattern(
      'USD',
      function (pattern) {
        alert('pattern: '  + pattern.pattern  + '\n' +
          'code: '     + pattern.code     + '\n' +
          'fraction: ' + pattern.fraction + '\n' +
          'rounding: ' + pattern.rounding + '\n' +
          'decimal: '  + pattern.decimal  + '\n' +
          'grouping: ' + pattern.grouping);
      },
      function () { alert('Error getting pattern\n'); }
    );

  });
  $$('#getDateNames').on('click',function () {
    navigator.globalization.getDateNames(
      function (names) {
        for (var i = 0; i < names.value.length; i++) {
          alert('month: ' + names.value[i] + '\n');
        }
      },
      function () { alert('Error getting names\n'); },
      { type: 'wide', item: 'months' }
    );
  })
  $$('#getDatePattern').on('click',function () {
    navigator.globalization.getDatePattern(
      function (date) { alert('pattern: ' + date.pattern + '\n'); },
      function () { alert('Error getting pattern\n'); },
      { formatLength: 'short', selector: 'date and time' }
    );
  })
  $$('#getFirstDayOfWeek').on('click',function () {
    // Beep twice!
    navigator.globalization.getFirstDayOfWeek(
      function (day) {alert('day: ' + day.value + '\n');},
      function () {alert('Error getting day\n');}
    );
  })
  $$('#getNumberPattern').on('click',function () {
    navigator.globalization.getNumberPattern(
      function (pattern) {
        alert('pattern: ' + pattern.pattern + '\n' +
          'symbol: ' + pattern.symbol + '\n' +
          'fraction: ' + pattern.fraction + '\n' +
          'rounding: ' + pattern.rounding + '\n' +
          'positive: ' + pattern.positive + '\n' +
          'negative: ' + pattern.negative + '\n' +
          'decimal: ' + pattern.decimal + '\n' +
          'grouping: ' + pattern.grouping);
      },
      function () {
        alert('Error getting pattern\n');
      },
      {type: 'decimal'}
    );
  })
  $$('#isDayLightSavingsTime').on('click',function () {
    navigator.globalization.isDayLightSavingsTime(
      new Date(),
      function (date) {alert('dst: ' + date.dst + '\n');},
      function () {alert('Error getting names\n');}
    );

  })
  $$('#numberToString').on('click',function () {
    navigator.globalization.numberToString(
      3.1415926,
      function (number) {alert('number: ' + number.value + '\n');},
      function () {alert('Error getting number\n');},
      {type:'decimal'}
    );
  })
  $$('#stringToDate').on('click',function () {
    navigator.globalization.stringToDate(
      '9/25/2012',
      function (date) {alert('month:' + date.month +
        ' day:'  + date.day   +
        ' year:' + date.year  + '\n');},
      function () {alert('Error getting date\n');},
      {selector: 'date'}
    );

  })
  $$('#stringToNumber').on('click',function () {
    navigator.globalization.stringToNumber(
      '1234.56',
      function (number) {alert('number: ' + number.value + '\n');},
      function () {alert('Error getting number\n');},
      {type:'decimal'}
    );
  })
});
