/**
 * Created by qiangxl on 2017/3/20.
 */
function onSuccess_motion(acceleration) {
  myApp.alert('Acceleration X: ' + acceleration.x + '\n' +
    'Acceleration Y: ' + acceleration.y + '\n' +
    'Acceleration Z: ' + acceleration.z + '\n' +
    'Timestamp: '      + acceleration.timestamp + '\n');
}
var watchID;
function onError_motion() {
  alert('onError!');
}
function onSuccess_watch(acceleration) {
  myApp.alert('Acceleration X: ' + acceleration.x + '\n' +
    'Acceleration Y: ' + acceleration.y + '\n' +
    'Acceleration Z: ' + acceleration.z + '\n' +
    'Timestamp: '      + acceleration.timestamp + '\n');
}

function onError_watch() {
  alert('onError!');
}
var options = { frequency: 5000 };  // Update every 3 seconds
myApp.onPageInit('page_device_motion',function () {
  console.debug('page_device_motion初始化')
  $$('#getCurrentAcceleration').on('click',function () {
    navigator.accelerometer.getCurrentAcceleration(onSuccess_motion, onError_motion);
  });
  $$('#watchAcceleration').on('click',function () {
    watchID = navigator.accelerometer.watchAcceleration(onSuccess_watch, onError_watch, options);
  });
  $$('#clearWatch').on('click',function () {
    navigator.accelerometer.clearWatch(watchID);
    myApp.alert('关闭观察模式')
  })
});
