
//------------------------------模拟数据----------------------------
var card_headers = ['一种过滤精细可减震式的混凝土搅拌机', '一种新型工艺品制作用固定串珠镊子', '一种含有改性矿渣的抗菌PET复合材料', '一个智能机器人'];
var card_prices = ['￥1600', '￥10000', '￥2500', '￥8780'];
var card_describs = ['实用新型 授权未缴费 截止2017-04-19', '实用新型 授权未缴费 截止2017-04-30', '实用新型 已下证 截止2017-07-19', '实用新型 授权未缴费 截止2017-09-19'];
var card_types = ['机械,搅拌机', '镊子', 'PET 抗菌材料', '电子，智能']


//---------------------初始化页面----------------------------------------
var myApp = new Framework7({
  precompileTemplates: true,
  template7Pages: true,
});
var mainView = myApp.addView('.view-main');
var $$ = Dom7;
initPageContent_ran();
infiniteScroll();

//-----------------------------------------分享。底部actionsheet----------------
$$('#fx').on('click', function () {
  var buttons = [
    {
      text: '微信',
      bold: true, color: "orange"
    },
    {
      text: '新浪',
      bold: true, color: "green"
    },
    {
      text: 'QQ',
      bold: true, color: "purple"
    },
    {
      text: '取消',
      bold: true, color: "red"
    },
  ];
  myApp.actions(buttons);
})


//------------------------------------根据script id template显示列表----------------------------
function initPageContent_ran() {

  var context = {
    card: [
      {
        card_header: card_headers[Math.floor(Math.random() * 4)],
        card_price: card_prices[Math.floor(Math.random() * 4)],
        card_describ: card_describs[Math.floor(Math.random() * 4)],
        card_type: card_types[Math.floor(Math.random() * 4)]
      },
      {
        card_header: card_headers[Math.floor(Math.random() * 4)],
        card_price: card_prices[Math.floor(Math.random() * 4)],
        card_describ: card_describs[Math.floor(Math.random() * 4)],
        card_type: card_types[Math.floor(Math.random() * 4)]
      },
      {
        card_header: card_headers[Math.floor(Math.random() * 4)],
        card_price: card_prices[Math.floor(Math.random() * 4)],
        card_describ: card_describs[Math.floor(Math.random() * 4)],
        card_type: card_types[Math.floor(Math.random() * 4)]
      },
      {
        card_header: card_headers[Math.floor(Math.random() * 4)],
        card_price: card_prices[Math.floor(Math.random() * 4)],
        card_describ: card_describs[Math.floor(Math.random() * 4)],
        card_type: card_types[Math.floor(Math.random() * 4)]
      },
      {
        card_header: card_headers[Math.floor(Math.random() * 4)],
        card_price: card_prices[Math.floor(Math.random() * 4)],
        card_describ: card_describs[Math.floor(Math.random() * 4)],
        card_type: card_types[Math.floor(Math.random() * 4)]
      },
      {
        card_header: card_headers[Math.floor(Math.random() * 4)],
        card_price: card_prices[Math.floor(Math.random() * 4)],
        card_describ: card_describs[Math.floor(Math.random() * 4)],
        card_type: card_types[Math.floor(Math.random() * 4)]
      }
    ]
  };
  var html_init = Template7.templates.template(context)
  $$('#content .list-block ul').html(html_init)
}
//------------------------------根据模板template_single无限滚动---------------------
function infiniteScroll() {
// 加载flag
  var loading = false;

// 上次加载的序号
  var lastIndex = $$('.list-block ul li').length;

// 最多可加载的条目
  var maxItems = 1000;

// 每次加载添加多少条目
  var itemsPerLoad = 10;
// 注册'infinite'事件处理函数
  $$('.infinite-scroll').on('infinite', function () {
    // 如果正在加载，则退出
    if (loading) return;

    // 设置flag
    loading = true;

    // 模拟1s的加载过程
    setTimeout(function () {
      // 重置加载flag
      loading = false;

      if (lastIndex >= maxItems) {
        // 加载完毕，则注销无限加载事件，以防不必要的加载
        myApp.detachInfiniteScroll($$('.infinite-scroll'));
        // 删除加载提示符
        $$('.infinite-scroll-preloader').remove();
        return;
      }

      var html_pre = '';
      //一次加载十个
      for (var i = lastIndex + 1; i <= lastIndex + itemsPerLoad; i++) {
        var context_single = {
          card_header: card_headers[Math.floor(Math.random() * 4)],
          card_price: card_prices[Math.floor(Math.random() * 4)],
          card_describ: card_describs[Math.floor(Math.random() * 4)],
          card_type: card_types[Math.floor(Math.random() * 4)]
        }
        html_pre += Template7.templates.template_single(context_single);
      }

      $$('#content .list-block ul').append(html_pre);

      // Update last loaded index
      lastIndex = $$('#content ul li').length;
    }, 1000);
  });

}
//------------------------------------------------------------------------

function sx_fm_res() {

  $$('#zllx').text("发明");
  $$('.grade-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
initPageContent_ran();
infiniteScroll()
}
function sx_syxx_res() {
  $$('#zllx').text("实用新型");
  $$('.grade-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_wgsj() {
  $$('#zllx').text("外观设计");
  $$('.grade-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_sqwjf_res() {
  $$('#zlzt').text("授权未缴费");
  $$('.Sort-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_yxz_res() {
  $$('#zlzt').text("已下证");
  $$('.Sort-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_1000_res() {
  $$('#jgfw').text("1000以下");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()

}
function sx_1000_2000_res() {
  $$('#jgfw').text("1000以下");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()

}
function sx_2000_3000_res() {
  $$('#jgfw').text("2000-3000");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_3000_5000_res() {
  $$('#jgfw').text("3000-5000");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_5000_10000_res() {
  $$('#jgfw').text("5000-10000");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_10000_50000_res() {
  $$('#jgfw').text("10000-50000");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_50000_res() {
  $$('#jgfw').text("50000以上");
  $$('.Category-eject').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_mr_res() {
  $$('#pxfs').text("默认");
  $$('.meishi22').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_fbsj_res() {
  $$('#pxfs').text("发布时间");
  $$('.meishi22').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_rq_res() {
  $$('#pxfs').text("人气");
  $$('.meishi22').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
function sx_jq_res() {
  $$('#pxfs').text("价格");
  $$('.meishi22').removeClass('grade-w-roll');
  $$('.screening').attr('style', 'position:static;margin-top:88px');
  initPageContent_ran();
  infiniteScroll()
}
