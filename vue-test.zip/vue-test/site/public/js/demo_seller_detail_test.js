myApp.onPageInit('page_seller_detail', function () {
hideToolbar();
//------------------------------模拟数据----------------------------
  myApp.alert('demo_seller_detail初始化');
  function mockData(count, callback) {
    var cards = [];
    for (var i = 1; i <= count; i++) {
      dataIndex++;
      cards.push({
        card_header: "一种过滤精细可减震式的混凝土搅拌机" + dataIndex,
        card_price: 1600 + dataIndex,
        card_describ: "实用新型 授权未缴费 截止2017-04-19 " + dataIndex,
        card_type: "机械,搅拌机," + dataIndex,
        card_company: "公司" + dataIndex
      })
    }
    callback({data: cards})
  }


//---------------------初始化页面----------------------------------------
  initPageContent_ran();
  infiniteScroll();

//-----------------------------------------分享。底部actionsheet----------------
  $$('#fx').on('click', function () {
    var buttons = [
      {
        text: '微信',
        bold: true, color: "orange"
      },
      {
        text: '新浪',
        bold: true, color: "green"
      },
      {
        text: 'QQ',
        bold: true, color: "purple"
      },
      {
        text: '取消',
        bold: true, color: "red"
      },
    ];
    myApp.actions(buttons);
  });


//------------------------------------根据script id template显示列表----------------------------
  function initPageContent_ran() {
    mockData(5, function (result) {
      var context_seller_detail = {card: result.data};
      var html_init = Template7.templates.template(context_seller_detail)
      $$('#content .list-block ul').html(html_init)
    })

  }

//------------------------------根据模板template_single无限滚动---------------------
  function infiniteScroll() {
// 加载flag
    var loading = false;

// 上次加载的序号
    var lastIndex = $$('.list-block ul li').length;

// 最多可加载的条目
    var maxItems = 1000;

// 每次加载添加多少条目
    var itemsPerLoad = 10;
// 注册'infinite'事件处理函数
    $$('.infinite-scroll').on('infinite', function () {
      // 如果正在加载，则退出
      if (loading) return;

      // 设置flag
      loading = true;

      // 模拟1s的加载过程
      setTimeout(function () {
        // 重置加载flag
        loading = false;

        if (lastIndex >= maxItems) {
          // 加载完毕，则注销无限加载事件，以防不必要的加载
          myApp.detachInfiniteScroll($$('.infinite-scroll'));
          // 删除加载提示符
          $$('.infinite-scroll-preloader').remove();
          return;
        }

        var html_pre = '';
        //一次加载十个
        mockData(itemsPerLoad,function (result) {
          var context_seller_detail_scroll={card:result.data};
          html_pre=Template7.templates.template(context_seller_detail_scroll);
        })
        $$('#content .list-block ul').append(html_pre);

        // Update last loaded index
        lastIndex = $$('#content ul li').length;
      }, 1000);
    });

  }

//------------------------------------------------------------------------

  function sx_fm_res() {

    $$('#zllx').text("发明");
    $$('.grade-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_syxx_res() {
    $$('#zllx').text("实用新型");
    $$('.grade-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_wgsj() {
    $$('#zllx').text("外观设计");
    $$('.grade-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_sqwjf_res() {
    $$('#zlzt').text("授权未缴费");
    $$('.Sort-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_yxz_res() {
    $$('#zlzt').text("已下证");
    $$('.Sort-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_1000_res() {
    $$('#jgfw').text("1000以下");
    $$('.Category-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()

  }

  function sx_1000_2000_res() {
    $$('#jgfw').text("1000以下");
    $$('.Category-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()

  }

  function sx_2000_3000_res() {
    $$('#jgfw').text("2000-3000");
    $$('.Category-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_3000_5000_res() {
    $$('#jgfw').text("3000-5000");
    $$('.Category-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_5000_10000_res() {
    $$('#jgfw').text("5000-10000");
    $$('.Category-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_10000_50000_res() {
    $$('#jgfw').text("10000-50000");
    $$('.Category-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_50000_res() {
    $$('#jgfw').text("50000以上");
    $$('.Category-eject').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_mr_res() {
    $$('#pxfs').text("默认");
    $$('.meishi22').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_fbsj_res() {
    $$('#pxfs').text("发布时间");
    $$('.meishi22').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_rq_res() {
    $$('#pxfs').text("人气");
    $$('.meishi22').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }

  function sx_jq_res() {
    $$('#pxfs').text("价格");
    $$('.meishi22').removeClass('grade-w-roll');
    $$('.screening').attr('style', 'position:static;margin-top:88px');
    initPageContent_ran();
    infiniteScroll()
  }
})