/**
 * Created by qiangxl on 2017/3/20.
 */
myApp.onPageInit('page_statusbar', function () {
  $$('#statusbar').on('click', function () {
    if (cordova.platformId == 'android') {
      StatusBar.backgroundColorByHexString("#333");
    }
  });
  $$('#statusbar_show').on('click', function () {
    StatusBar.show();
  });
  $$('#statusbar_hide').on('click', function () {
    StatusBar.hide();
  });
  console.debug('page_statusbar初始化')
});