/**
 * Created by qiangxl on 2017/3/20.
 */
function downloadImage(){

  window.requestFileSystem(LocalFileSystem.PERSISTENT,0,function (fs) {

    console.log('打开的文件系统: '+fs.name);
    var url = 'https://static.taoquanw.com/upload/shop/store/goods/14/2016/14_05325438128551501_360.png';
    fs.root.getFile('taoquanw_down.png', {create:true,exclusive:false},
      function (fileEntry){
        download(fileEntry,url);
      }, function(error){
        console.log("文件创建失败！"+error)
      });

  }, function(error){
    console.log("文件系统加载失败！"+error)
  });
}




//下载文件
function download(fileURL,uri) {
  var fileTransfer = new FileTransfer();
  // var fileURL=fileEntry.toURL();
  fileTransfer.onprogress = function(progressEvent) {
    if (progressEvent.lengthComputable) {
      console.log("当前进度："+progressEvent.loaded / progressEvent.total);
    }
  };
  fileTransfer.download(uri,fileURL,function (entry) {
      console.log("下载成功！");
      console.log("文件保存位置: "+entry.toURL());
      $$('#showdownPic').attr('src',entry.toURL());
    },
    function (error) {
      console.log("下载失败！");
      console.log("error source "+error.source);
      console.log("error target "+error.target);
      console.log("error code"+error.code);
    },
    null, // or, pass false
    {
      //headers: {
      //    "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
      //}
    }
  );

}

//文件创建失败回调


//FileSystem加载失败回调




myApp.onPageInit('page_file_transfer',function () {
  $$('#fileUpload').on('click',function () {
    var fileURL='cdvfile://localhost/persistent/taoquanw.png';
    var options = new FileUploadOptions();
    options.fileKey = "file";
    options.fileName = fileURL.substr(fileURL.lastIndexOf('/') + 1);
    options.mimeType = "text/plain";

    var params = {};
    params.value1 = "test";
    params.value2 = "param";
    options.params = params;

    var ft = new FileTransfer();
    ft.upload(fileURL, encodeURI("http://some.server.com/upload.php"), function (r) {
      console.log("Code = " + r.responseCode);
      console.log("Response = " + r.response);
      console.log("Sent = " + r.bytesSent);
    }, function (error) {
      alert("An error has occurred: Code = " + error.code);
      console.log("upload error source " + error.source);
      console.log("upload error target " + error.target);
    }, options);
  });
  $$('#fileDownload').on('click',function () {
    var fileURL = 'cdvfile://localhost/persistent/taoquanw_down.png';
    var url = 'https://static.taoquanw.com/upload/shop/store/goods/14/2016/14_05325438128551501_360.png';
    download(fileURL,url);

  })

  console.debug('page_file_transfer初始化')
});