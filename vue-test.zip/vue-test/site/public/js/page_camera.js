/**
 * Created by qiangxl on 2017/3/20.
 */
document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
  console.log(navigator.camera);
}
myApp.onPageInit('page_camera',function () {
  $$('#openCamera').on('click',function () {
    myApp.alert('进入拍照方法')
    navigator.camera.getPicture(onSuccess_img, onFail, { quality: 50,
      destinationType: Camera.DestinationType.FILE_URI });
    console.debug('进入拍照')
  });
  console.debug('page_camera初始化')
});
function onSuccess_img(imageURI) {
  var image = document.getElementById('showPicture');
  image.src = imageURI;
  console.debug('拍照成功')
}
function onFail(message) {
  console.error('Failed because: ' + message);
}