/**
 * Created by qiangxl on 2017/3/20.
 */
var watchID_locationWatch;
var onSuccess_location = function(position) {
  alert('Latitude: '          + position.coords.latitude          + '\n' +
    'Longitude: '         + position.coords.longitude         + '\n' +
    'Altitude: '          + position.coords.altitude          + '\n' +
    'Accuracy: '          + position.coords.accuracy          + '\n' +
    'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
    'Heading: '           + position.coords.heading           + '\n' +
    'Speed: '             + position.coords.speed             + '\n' +
    'Timestamp: '         + position.timestamp                + '\n');
};

// onError Callback receives a PositionError object
//
function onError_location(error) {
  alert('code: '    + error.code    + '\n' +
    'message: ' + error.message + '\n');
}
function onSuccess_location_watch(position) {
  var element = document.getElementById('geolocation');
  element.innerHTML = 'Latitude: '  + position.coords.latitude      + '<br />' +
    'Longitude: ' + position.coords.longitude     + '<br />' +
    '<hr />'      + element.innerHTML;
}

// onError Callback receives a PositionError object
//
function onError(error) {
  alert('code: '    + error.code    + '\n' +
    'message: ' + error.message + '\n');
}





var onWeatherSuccess = function (position) {

  Latitude = position.coords.latitude;
  Longitude = position.coords.longitude;

  getWeather(Latitude, Longitude);
}

// Get weather by using coordinates

function getWeather(latitude, longitude) {

  // Get a free key at http://openweathermap.org/. Replace the "Your_Key_Here" string with that key.
  var OpenWeatherAppKey = "d2ed67ad0c826ea1bfec4641cabdd957";

  var queryString =
    'http://api.openweathermap.org/data/2.5/weather?lat='
    + latitude + '&lon=' + longitude + '&appid=' + OpenWeatherAppKey + '&units=imperial';

  $.getJSON(queryString, function (results) {

    if (results.weather.length) {

      $.getJSON(queryString, function (results) {

        if (results.weather.length) {

          $('#description').text(results.name);
          $('#temp').text(results.main.temp);
          $('#wind').text(results.wind.speed);
          $('#humidity').text(results.main.humidity);
          $('#visibility').text(results.weather[0].main);

          var sunriseDate = new Date(results.sys.sunrise);
          $('#sunrise').text(sunriseDate.toLocaleTimeString());

          var sunsetDate = new Date(results.sys.sunrise);
          $('#sunset').text(sunsetDate.toLocaleTimeString());
        }

      });
    }
  }).fail(function () {
    console.log("error getting location");
  });
}

// Error callback

function onWeatherError(error) {
  console.log('code: ' + error.code + '\n' +
    'message: ' + error.message + '\n');
}

var onWeatherWatchSuccess = function (position) {

  var updatedLatitude = position.coords.latitude;
  var updatedLongitude = position.coords.longitude;

  if (updatedLatitude != Latitude && updatedLongitude != Longitude) {

    Latitude = updatedLatitude;
    Longitude = updatedLongitude;

    // Calls function we defined earlier.
    getWeather(updatedLatitude, updatedLongitude);
  }
}

myApp.onPageInit('page_geolocation',function () {
  $$('#openLocation').on('click',function () {
    navigator.geolocation.getCurrentPosition(onSuccess_location, onError_location);

  });
  $$('#openLocation_watch').on('click',function () {
    // enableHighAccuracy,　　　//boolean 是否要求高精度的地理信息
    //   timeout,　　　　　　　　　//表示等待响应的最大时间，默认是0毫秒，表示无穷时间
    // maximumAge　　　　　　　　/应用程序的缓存时间
    var geolocationOptions={ maximumAge: 3000, timeout: 30000, enableHighAccuracy: true };
    watchID_locationWatch = navigator.geolocation.watchPosition(onSuccess_location_watch, onError_location,geolocationOptions );

  });
  $$('#closeLocation_watch').on('click',function () {
    navigator.geolocation.clearWatch(watchID_locationWatch);
  })
  $$('#getWeatherForecast').on('click',function () {
    navigator.geolocation.getCurrentPosition
    (onWeatherSuccess, onWeatherError, { enableHighAccuracy: true });
  })
  $$('#getWeatherForecast_watch').on('click',function () {
    navigator.geolocation.watchPosition
    (onWeatherWatchSuccess, onWeatherError, { enableHighAccuracy: true });
  })
  console.debug('page_geolocation初始化')
});