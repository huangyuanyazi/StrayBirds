var myList;
myApp.onPageInit('page_search', function () {
  hideToolbar();
var chip_index = 0;
var history_index=0;
  var autocompleteDropdownAjax = myApp.autocomplete({
    input: '#autocomplete-dropdown-ajax',
    openIn: 'dropdown',
    preloader: true, //enable preloader
    valueProperty: 'id', //object's "value" property name
    textProperty: 'name', //object's "text" property name
    limit: 20, //limit to 20 results
    dropdownPlaceholderText: '试试搜索 "油烟机的发明"',
    expandInput: true, // expand input
    source: function (autocomplete, query, render) {
      var results = [];
      if (query.length === 0) {
        render(results);
        return;
      }
      // Show Preloader
      autocomplete.showPreloader();
      // Do Ajax request to Autocomplete data
      $$.ajax({
        url: 'json/autocomplete-searchData.json',
        method: 'GET',
        dataType: 'json',
        //send "query" to server. Useful in case you generate response dynamically
        data: {
          query: query
        },
        success: function (data) {
          // Find matched items
          for (var i = 0; i < data.length; i++) {
            if (data[i].name.toLowerCase().indexOf(query.toLowerCase()) >= 0) results.push(data[i]);
          }
          // Hide Preoloader
          autocomplete.hidePreloader();
          // Render items by passing array with result items
          render(results);
        }
      });
    }
  });
function getKey() {
  console.log(event)
  if (event.keyCode == 13) {
    if ($('#autocomplete-dropdown-ajax').val().length > 0) {
      alert(2222222)

    }
  }
}

// $$('#cancel').on('click',function () {
//   alert(11111111)
//   $$('.screening').show()
// })
  alert('搜索界面');

  var ran_data_chip = function (count, callback) {

    var data_arr = [];
    for (var i = 0; i < count; i++) {
      chip_index++;
      data_arr.push({
        chip_content: '热门搜索' + chip_index
      })
    }
    callback({data: data_arr})
  };
  var ran_data_history = function (count, callback) {

    var data_arr_history = [];
    for (var i = 0; i < count; i++) {
      history_index++;
      data_arr_history.push({
        history_key: '搜索历史' + history_index
      })
    }
    callback({data: data_arr_history})
  };

  ran_data_chip(6, function (result) {
    var context_chip = {chips: result.data};
    var html_chip = Template7.templates.page_search_chip(context_chip);
    $$('#hotSearch .card-content-inner').html(html_chip)
  })

  ran_data_history(10,function (result) {
    // alert(result.data)
    myList = myApp.virtualList('.list-block.virtual-list', {
      // Array with items data
      items: result.data,
      // Template 7 template to render each item
      template:Template7.templates.page_search_history
    });
  });


});
function clearHistory() {
myList.deleteAllItems()
  $$('.page-content').scrollTop
}