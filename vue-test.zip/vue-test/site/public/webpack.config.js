var webpack = require('webpack');

var config = {
entry:{
hoho:"./vue"
},
output:{
path:path.resolve('dist'),
filename:'[name].js'
}
}
module.exports=config