/**
 * Created by henry on 2017/4/13 0013.
 */
"use strict";

module.exports.rules =  {};
module.exports.through = true;