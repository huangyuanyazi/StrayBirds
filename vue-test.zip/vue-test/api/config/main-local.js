/**
 * Created by henry on 2017/3/13 0013.
 */
"use strict";

module.exports = {
	debug: true,
};