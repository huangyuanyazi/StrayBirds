/**
 * Created by henry on 2017/3/13 0013.
 */
"use strict";

module.exports = {
	debug: false,
	port: 9090,
	backend: 'http://localhost:8080',
	validationPath: '/v1/validation'
};